DATABASE_URL = "postgresql+asyncpg://postgres:postgres@db:5432/distcomp"
