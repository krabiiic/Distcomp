package com.example.entitiesapp.model;

public interface BaseEntity {
    Long getId();
    void setId(Long id);
} 