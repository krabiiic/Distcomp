package com.example.entitiesapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EntitiesAppApplication {
    public static void main(String[] args) {
        SpringApplication.run(EntitiesAppApplication.class, args);
    }
} 