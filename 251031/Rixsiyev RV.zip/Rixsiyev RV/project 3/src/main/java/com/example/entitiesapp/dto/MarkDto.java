package com.example.entitiesapp.dto;

import lombok.Data;

@Data
public class MarkDto implements BaseDto {
    private Long id;
    private String name;
} 