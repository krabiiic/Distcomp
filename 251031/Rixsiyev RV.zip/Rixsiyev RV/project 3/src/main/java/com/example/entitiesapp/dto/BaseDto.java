package com.example.entitiesapp.dto;

public interface BaseDto {
    Long getId();
    void setId(Long id);
} 