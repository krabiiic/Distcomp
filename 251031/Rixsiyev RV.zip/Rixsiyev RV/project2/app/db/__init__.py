"""
Модуль для работы с базой данных
"""
from app.db.init_db import init_db
 
__all__ = ['init_db'] 