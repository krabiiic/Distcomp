"""
Модуль с моделями данных
"""
from app.models.entities import User, Topic, Mark, Message
 
__all__ = ['User', 'Topic', 'Mark', 'Message'] 